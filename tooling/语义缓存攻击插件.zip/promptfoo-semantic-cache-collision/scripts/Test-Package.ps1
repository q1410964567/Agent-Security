[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [string]$PromptfooRoot
)

$ErrorActionPreference = 'Stop'
if (-not [System.IO.Directory]::Exists($PromptfooRoot)) {
  throw "PromptfooRoot does not exist or is not a directory: $PromptfooRoot"
}
$PromptfooRoot = [System.IO.Path]::GetFullPath($PromptfooRoot)
Push-Location $PromptfooRoot
try {
  if (-not [System.IO.Directory]::Exists((Join-Path $PromptfooRoot 'node_modules'))) {
    throw 'Promptfoo dependencies are missing. Run pnpm install in the Promptfoo checkout first.'
  }
  & pnpm vitest run test/redteam/plugins/semanticCacheCollision.test.ts
  if ($LASTEXITCODE -ne 0) { throw 'Focused plugin tests failed.' }
} finally {
  Pop-Location
}
