[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [string]$PromptfooRoot,
  [switch]$Force
)

$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
if (-not [System.IO.Directory]::Exists($PromptfooRoot)) {
  throw "PromptfooRoot does not exist or is not a directory: $PromptfooRoot"
}
$PromptfooRoot = [System.IO.Path]::GetFullPath($PromptfooRoot)
$expectedCommit = 'b408bf454a5471fe4f18f7aeb8695736c1b4623e'

if (-not [System.IO.Directory]::Exists((Join-Path $PromptfooRoot '.git'))) {
  throw "PromptfooRoot must be a Git checkout: $PromptfooRoot"
}
if (-not [System.IO.Directory]::Exists((Join-Path $PromptfooRoot 'src\redteam\plugins'))) {
  throw 'Promptfoo source layout not recognised (src\\redteam\\plugins is missing).'
}

$currentCommit = (& git -C $PromptfooRoot rev-parse HEAD).Trim()
if ($currentCommit -ne $expectedCommit) {
  Write-Warning "This kit was verified against $expectedCommit, but the target is $currentCommit. The registration patch may need updating."
}

$pluginDestination = Join-Path $PromptfooRoot 'src\redteam\plugins\semanticCacheCollision.ts'
$testDestination = Join-Path $PromptfooRoot 'test\redteam\plugins\semanticCacheCollision.test.ts'
if (([System.IO.File]::Exists($pluginDestination) -or [System.IO.File]::Exists($testDestination)) -and -not $Force) {
  throw 'Plugin overlay already exists. Inspect it first, or rerun with -Force to replace only the two overlay files.'
}

$patch = Join-Path $kitRoot 'patches\register-semantic-cache-collision.patch'
& git -C $PromptfooRoot apply --check $patch
if ($LASTEXITCODE -ne 0) {
  throw 'Registration patch does not apply cleanly. Stop and resolve the Promptfoo version/diff before installing.'
}

Copy-Item -LiteralPath (Join-Path $kitRoot 'overlay\src\redteam\plugins\semanticCacheCollision.ts') -Destination $pluginDestination -Force
Copy-Item -LiteralPath (Join-Path $kitRoot 'overlay\test\redteam\plugins\semanticCacheCollision.test.ts') -Destination $testDestination -Force
& git -C $PromptfooRoot apply $patch
if ($LASTEXITCODE -ne 0) {
  throw 'Unexpected failure while applying the registration patch.'
}

Write-Host 'Installed semantic-cache-collision overlay and registrations.' -ForegroundColor Green
Write-Host 'Next: run the focused Vitest command in README, then rebuild your Promptfoo image.'
