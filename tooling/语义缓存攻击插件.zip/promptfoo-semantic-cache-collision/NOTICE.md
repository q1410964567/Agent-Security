# Third-party notices

## Promptfoo

This kit contains an overlay and registration patch for [Promptfoo](https://github.com/promptfoo/promptfoo), tested against commit `b408bf454a5471fe4f18f7aeb8695736c1b4623e`. Promptfoo is MIT licensed. Its source is **not** included in this repository.

## CacheAttack research implementation

The adapter can call the authors' implementation associated with *From Similarity to Vulnerability: Key Collision Attack on LLM Semantic Caching* (ICML 2026): <https://github.com/Zzx1011/CacheAttack>.

No CacheAttack source code, model weights, datasets, or credentials are bundled or redistributed by this kit. Obtain the source directly from the authors and follow the upstream licence, model licences, and usage terms before enabling `SEMANTIC_CACHE_PLUGIN_REAL_ATTACK=1`.

## Safety boundary

This project is for authorised evaluation of a staging system or the included synthetic target. The included tool actions are simulated audit records only; no real external operation is performed by the kit.
