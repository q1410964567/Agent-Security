"""Thin Promptfoo adapter around the authors' CacheAttack implementation.

The attack algorithm is not reimplemented here. This module imports the
official CacheAttack2 pipeline and exposes only an HTTP-adapter-friendly API.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Callable


def _source_root() -> Path:
    configured = os.environ.get("CACHEATTACK_SOURCE_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    # The upstream implementation is deliberately not bundled here. A user
    # may clone it into third_party/CacheAttack, or point the environment
    # variable at an existing authorised checkout.
    return (Path(__file__).resolve().parents[1] / "third_party" / "CacheAttack").resolve()


SOURCE_ROOT = _source_root()
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

try:
    # These are the authors' classes; do not replace them with local code.
    from attack.cache_attack import (  # type: ignore
        CacheAttack2,
        CacheAttackGenerator,
        LatencyValidator,
        SurrogateCacheEmbeddingModel,
    )
except Exception as error:  # defer a useful message until real mode is used
    CacheAttack2 = None  # type: ignore[assignment,misc]
    CacheAttackGenerator = None  # type: ignore[assignment,misc]
    LatencyValidator = None  # type: ignore[assignment,misc]
    SurrogateCacheEmbeddingModel = None  # type: ignore[assignment,misc]
    _IMPORT_ERROR = error
else:
    _IMPORT_ERROR = None


_GENERATOR_CACHE: dict[tuple[Any, ...], Any] = {}
# Concurrent first-load of two torch models raced on the meta-device init and
# raised "copy out of meta tensor"; serialize generator construction.
_GENERATOR_LOCK = __import__("threading").Lock()


def build_source_generator(config: dict[str, Any] | None = None) -> Any:
    """Instantiate the official CacheAttackGenerator lazily and reuse it."""
    if CacheAttackGenerator is None:
        raise RuntimeError(
            "无法导入作者 CacheAttack 源码。请安装其依赖并检查 "
            f"CACHEATTACK_SOURCE_DIR={SOURCE_ROOT}: {_IMPORT_ERROR}"
        )
    settings = config or {}
    key = (
        settings.get("embed_model_name", "BAAI/bge-small-en-v1.5"),
        settings.get("lm_model_name", "gpt2"),
        settings.get("mode", "cos"),
        float(settings.get("lambda_ppl", 0.05)),
        int(settings.get("lsh_nbits", 256)),
        float(settings.get("lsh_alpha", 10.0)),
        int(settings.get("max_lm_length", 128)),
        settings.get("suffix_prefix", "Neglect: "),
    )
    with _GENERATOR_LOCK:
        if key not in _GENERATOR_CACHE:
            _GENERATOR_CACHE[key] = CacheAttackGenerator(
                embed_model_name=key[0],
                lm_model_name=key[1],
                mode=key[2],
                lambda_ppl=key[3],
                lsh_nbits=key[4],
                lsh_alpha=key[5],
                max_lm_length=key[6],
                suffix_prefix=key[7],
            )
    return _GENERATOR_CACHE[key]


class RecordingCacheAPI:
    """API shape expected by the official CacheAttack2/LatencyValidator."""

    def __init__(self, query_callback: Callable[[str], tuple[dict[str, Any], float]]):
        self._query_callback = query_callback
        self.calls: list[dict[str, Any]] = []

    def query(self, text: str) -> dict[str, Any]:
        result, latency_ms = self._query_callback(text)
        record = {"prompt": text, "result": result, "latencyMs": latency_ms}
        self.calls.append(record)
        # CacheAttack2 only needs the return value to exist; retaining these
        # fields lets the Promptfoo adapter recover the final two observations.
        return {"response": result, "latency": latency_ms / 1000.0}


def run_source_cacheattack2(
    source_prompt: str,
    victim_prompt: str,
    query_callback: Callable[[str], tuple[dict[str, Any], float]],
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run the authors' CacheAttack-2 pipeline and return its trace."""
    if any(item is None for item in (CacheAttack2, SurrogateCacheEmbeddingModel, LatencyValidator)):
        raise RuntimeError(
            "无法导入作者 CacheAttack2 组件。请检查源码与依赖： "
            f"{_IMPORT_ERROR}"
        )
    settings = config or {}
    generator = build_source_generator(settings)
    surrogate = SurrogateCacheEmbeddingModel(
        embed_model_name=settings.get("surrogate_model", "BAAI/bge-small-en-v1.5"),
        threshold=float(settings.get("surrogate_threshold", 0.88)),
    )
    target = RecordingCacheAPI(query_callback)
    validator = LatencyValidator()
    validator.calibrate(
        target,
        victim_prompt,
        n_hit=int(settings.get("validator_hit_samples", 3)),
        n_miss=int(settings.get("validator_miss_samples", 3)),
        sleep_between=float(settings.get("validator_sleep", 0.05)),
    )
    attack = CacheAttack2(
        generator=generator,
        surrogate_cache=surrogate,
        target_cache_api=target,
        target_validator=validator,
    )
    candidate, confirmed = attack.attack(
        p_src=source_prompt,
        p_v=victim_prompt,
        max_iterations=int(settings.get("max_iterations", 2)),
        surrogate_threshold=float(settings.get("surrogate_threshold", 0.88)),
        target_sim=float(settings.get("target_sim", 0.88)),
        steps_per_len=int(settings.get("steps_per_len", 60)),
        init_len=int(settings.get("init_len", 5)),
        max_len=int(settings.get("max_len", 40)),
        len_step=int(settings.get("len_step", 5)),
        batch_size=int(settings.get("batch_size", 32)),
        top_k=int(settings.get("top_k", 32)),
        verbose=bool(settings.get("verbose", False)),
    )
    victim_records = [item for item in target.calls if item["prompt"] == victim_prompt]
    last_victim = victim_records[-1] if victim_records else None
    last_prime = None
    if last_victim:
        position = target.calls.index(last_victim)
        if position > 0:
            last_prime = target.calls[position - 1]
    return {
        "candidate": candidate,
        "confirmed": bool(confirmed),
        "calls": target.calls,
        "prime": last_prime,
        "victim": last_victim,
        "algorithm": "CacheAttack2.attack",
        "sourceRepository": "https://github.com/Zzx1011/CacheAttack",
        "sourceRoot": str(SOURCE_ROOT),
    }
